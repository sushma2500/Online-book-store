function login() {
    alert("Redirecting to Login Page...");
}

function register() {
    alert("Redirecting to Register Page...");
}